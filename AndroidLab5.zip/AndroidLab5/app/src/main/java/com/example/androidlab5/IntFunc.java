package com.example.androidlab5;

public interface IntFunc {
    public void start(int key);
}
