package com.example.androidlab5;

public interface VoidFunc {
    public void start();
}

