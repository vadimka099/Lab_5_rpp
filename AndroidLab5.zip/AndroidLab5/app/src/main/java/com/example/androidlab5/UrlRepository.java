package com.example.androidlab5;

import android.os.AsyncTask;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class UrlRepository {
    private static UrlRepository instance;
    private List<String> urls;
    private String breedId;
    private UrlRepository(String breedId) {
        urls = new ArrayList<>();
        urls.add("https://cdn2.thecatapi.com/images/csl.jpg");
        this.breedId = breedId;
    }

    public static UrlRepository createInstance(String breedId) {
        if(instance == null) {
            instance = new UrlRepository(breedId);
        }
        if(instance != null && instance.breedId != breedId) {
            instance = new UrlRepository(breedId);
        }
        return instance;
    }
    public List<String> getUrls() {
        return urls;
    }

    public void addUrls(List<String> urls) {
        this.urls.addAll(urls);
    }

    public static UrlRepository getInstance() {
        return instance;
    }

    public void load() {
        HttpHandler httpHandler = new HttpHandler();
        httpHandler.execute(breedId);
    }

    public class HttpHandler extends AsyncTask<String, Void, List<String>> {

        @Override
        protected void onPostExecute(List<String> strings) {
            super.onPostExecute(strings);
            UrlRepository.getInstance().addUrls(strings);
        }

        @Override
        protected List<String> doInBackground(String... strings) {
            String breedId = strings[0];
            List<String> urls = new ArrayList<>();
            OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .addHeader("x-api-key", "8b399562-7d23-44ba-a61a-316c1fa086fe")
                        .url("https://api.thecatapi.com/v1/images/search?limit=9&breed_ids=" + breedId)
                        .build();
                try (Response response = client.newCall(request).execute()) {
                    String body = response.body().string();
                    ObjectMapper mapper = new ObjectMapper();
                    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
                    List<Url> urlList = mapper.readValue(body, new TypeReference<List<Url>>(){});
                    for(Url url : urlList) {
                        urls.add(url.getUrl());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            return urls;
        }
    }

}
